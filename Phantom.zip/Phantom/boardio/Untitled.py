Long Endgame 1: 8/1r5n/8/8/5k2/1b6/3K3N/7Q b - - 0 1
Annoyance: 8/1P4R1/K2k2p1/8/8/7p/1r6/8 w - - 0 67

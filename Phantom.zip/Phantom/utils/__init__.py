# -*- coding: utf-8 -*-

"""A small package of utilities that make things easier."""

pass

# -*- coding: utf-8 -*-

"""Predicting what the board will be."""

pass

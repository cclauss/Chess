# -*- coding: utf-8 -*-

"""A chess engine.  Not particularly fast nor powerful, but a chess engine."""

pass

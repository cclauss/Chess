# -*- coding: utf-8

"""A basic position evaluator."""

pass

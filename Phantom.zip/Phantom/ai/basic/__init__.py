# -*- coding: utf-8 -*-

"""A basic AI.  Analogous to a good AI set to 'easy' level.  In fact, this particular AI makes completely random moves."""

pass

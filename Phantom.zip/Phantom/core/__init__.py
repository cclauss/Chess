# -*- coding: utf-8 -*-

"""The core of the game."""

pass
